
bool WriteProcessID(char* processFullPath, char* pidFile, int bufSize);
